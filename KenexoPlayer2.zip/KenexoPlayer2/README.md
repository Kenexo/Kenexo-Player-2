# Kenexo Player 2

Open this folder in Android Studio (Koala or newer, JDK 17) -> Sync -> Run.

Included: device video library (MediaStore) with search / folder filter / sort, thumbnails,
Media3 ExoPlayer, swipe left = brightness, swipe right = volume, double-tap = seek 10s,
speed control, screen lock, Picture-in-Picture, resume position, network streams (MP4/HLS/DASH).

Next: subtitles, audio tracks, A-B repeat, sleep timer, background playback (MediaSession),
Room history, Chromecast, equalizer, AMOLED theme.

---

ስም፦ Kenasa • CEO, KENEXO
ቴሌግራም ቻናል፦ @ethiopsiphonn (t.me/ethiopsiphonn)
ማግኛ፦ t.me/kenexo
