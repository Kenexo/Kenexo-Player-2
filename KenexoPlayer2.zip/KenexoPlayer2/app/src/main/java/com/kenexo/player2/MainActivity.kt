package com.kenexo.player2

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import coil.ImageLoader
import coil.compose.AsyncImage
import coil.decode.VideoFrameDecoder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) { LibraryScreen() }
            }
        }
    }
}

private val PERM =
    if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
    else Manifest.permission.READ_EXTERNAL_STORAGE

private fun hasPerm(c: Context) =
    ContextCompat.checkSelfPermission(c, PERM) == PackageManager.PERMISSION_GRANTED

private fun openPlayer(c: Context, uri: Uri, title: String) {
    c.startActivity(Intent(c, PlayerActivity::class.java).apply {
        data = uri
        putExtra("title", title)
    })
}

private fun fmt(ms: Long): String {
    val s = ms / 1000
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%02d:%02d".format(m, sec)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen() {
    val ctx = LocalContext.current
    var videos by remember { mutableStateOf(emptyList<VideoItem>()) }
    var granted by remember { mutableStateOf(hasPerm(ctx)) }
    var query by remember { mutableStateOf("") }
    var folder by remember { mutableStateOf<String?>(null) }
    var sortByName by remember { mutableStateOf(false) }
    var showUrl by remember { mutableStateOf(false) }
    var url by remember { mutableStateOf("") }
    var showAbout by remember { mutableStateOf(false) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    LaunchedEffect(Unit) { if (!granted) launcher.launch(PERM) }
    LaunchedEffect(granted) {
        if (granted) videos = withContext(Dispatchers.IO) { VideoRepository.load(ctx) }
    }

    val loader = remember {
        ImageLoader.Builder(ctx).components { add(VideoFrameDecoder.Factory()) }.build()
    }
    val folders = remember(videos) { videos.map { it.folder }.distinct().sorted() }
    val shown = remember(videos, query, folder, sortByName) {
        videos.filter { (folder == null || it.folder == folder) && it.title.contains(query, true) }
            .let { if (sortByName) it.sortedBy { v -> v.title.lowercase() } else it }
    }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text("Kenexo Player 2") },
            actions = {
                TextButton(onClick = { sortByName = !sortByName }) {
                    Text(if (sortByName) "A-Z" else "Newest")
                }
                TextButton(onClick = { showUrl = true }) { Text("URL") }
                TextButton(onClick = { showAbout = true }) { Text("About") }
            }
        )
    }) { pad ->
        Column(Modifier.padding(pad)) {
            OutlinedTextField(
                value = query, onValueChange = { query = it },
                placeholder = { Text("Search") }, singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp)
            )
            LazyRow(
                contentPadding = PaddingValues(12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item { FilterChip(folder == null, { folder = null }, label = { Text("All") }) }
                items(folders) { f ->
                    FilterChip(folder == f, { folder = if (folder == f) null else f }, label = { Text(f) })
                }
            }
            if (!granted) {
                Box(Modifier.fillMaxSize(), Alignment.Center) {
                    Button(onClick = { launcher.launch(PERM) }) { Text("Allow video access") }
                }
            } else {
                LazyColumn(contentPadding = PaddingValues(horizontal = 12.dp)) {
                    items(shown, key = { it.id }) { v ->
                        Row(
                            Modifier.fillMaxWidth()
                                .clickable { Playlist.items = shown; openPlayer(ctx, v.uri, v.title) }
                                .padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(Modifier.size(128.dp, 72.dp).clip(RoundedCornerShape(8.dp))) {
                                AsyncImage(
                                    model = v.uri, imageLoader = loader,
                                    contentDescription = null,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                                Text(
                                    fmt(v.durationMs),
                                    style = MaterialTheme.typography.labelSmall,
                                    modifier = Modifier.align(Alignment.BottomEnd).padding(4.dp)
                                )
                            }
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text(v.title, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Text(
                                    "${v.folder} • ${v.sizeBytes / 1_048_576} MB",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showUrl) {
        AlertDialog(
            onDismissRequest = { showUrl = false },
            title = { Text("Network stream") },
            text = {
                OutlinedTextField(
                    value = url, onValueChange = { url = it },
                    placeholder = { Text("https://…/video.mp4 or .m3u8 or .mpd") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (url.isNotBlank()) { Playlist.items = emptyList(); openPlayer(ctx, Uri.parse(url.trim()), url.trim()) }
                    showUrl = false
                }) { Text("Play") }
            },
            dismissButton = { TextButton(onClick = { showUrl = false }) { Text("Cancel") } }
        )
    }

    if (showAbout) AboutDialog { showAbout = false }
}

@Composable
private fun AboutDialog(onDismiss: () -> Unit) {
    val uri = LocalUriHandler.current
    @Composable
    fun Link(label: String, url: String) {
        Text(
            label,
            color = Color(0xFF4FC3F7),
            textDecoration = TextDecoration.Underline,
            modifier = Modifier.clickable { uri.openUri(url) }.padding(vertical = 4.dp)
        )
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Kenexo Player 2") },
        text = {
            Column {
                Text("ስም፦ Kenasa • CEO, KENEXO", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Text("ቴሌግራም ቻናል፦")
                Link("@ethiopsiphonn (t.me/ethiopsiphonn)", "https://t.me/ethiopsiphonn")
                Spacer(Modifier.height(8.dp))
                Text("ማግኛ፦")
                Link("t.me/kenexo", "https://t.me/kenexo")
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}
