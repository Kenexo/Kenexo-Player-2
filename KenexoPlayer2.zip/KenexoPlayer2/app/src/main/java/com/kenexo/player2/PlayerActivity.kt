package com.kenexo.player2

import android.app.PictureInPictureParams
import android.content.ContentValues
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.media.AudioManager
import android.media.MediaMetadataRetriever
import android.media.audiofx.Equalizer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Rational
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay
import java.io.File
import kotlin.concurrent.thread
import kotlin.math.roundToInt

class PlayerActivity : ComponentActivity() {

    private lateinit var player: ExoPlayer
    private lateinit var prefs: SharedPreferences

    private var inPip by mutableStateOf(false)
    private var isPlayingState by mutableStateOf(true)
    private var curTitle by mutableStateOf("")
    private var tracks by mutableStateOf(Tracks.EMPTY)
    private var repeatState by mutableIntStateOf(Player.REPEAT_MODE_OFF)
    private var shuffleState by mutableStateOf(false)

    private var eq: Equalizer? = null
    private var eqOn = false
    private val eqLevels = mutableMapOf<Int, Short>()

    private val subtitlePicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) loadSubtitle(uri)
        }

    private fun mediaItem(uri: Uri, title: String) = MediaItem.Builder()
        .setUri(uri)
        .setMediaMetadata(MediaMetadata.Builder().setTitle(title).build())
        .build()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val data = intent.data ?: run { finish(); return }
        prefs = getSharedPreferences("resume", Context.MODE_PRIVATE)

        val list = Playlist.items
        val idx = list.indexOfFirst { it.uri == data }
        val items: List<MediaItem>
        val start: Int
        if (idx >= 0) {
            items = list.map { mediaItem(it.uri, it.title) }
            start = idx
        } else {
            items = listOf(mediaItem(data, intent.getStringExtra("title") ?: ""))
            start = 0
        }
        curTitle = items[start].mediaMetadata.title?.toString() ?: ""

        player = ExoPlayer.Builder(this).build().apply {
            setMediaItems(items, start, prefs.getLong(data.toString(), 0L))
            prepare()
            playWhenReady = true
        }
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { isPlayingState = isPlaying }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                curTitle = mediaItem?.mediaMetadata?.title?.toString() ?: ""
            }
            override fun onTracksChanged(t: Tracks) { tracks = t }
            override fun onRepeatModeChanged(repeatMode: Int) { repeatState = repeatMode }
            override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
                shuffleState = shuffleModeEnabled
            }
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                eq?.release(); eq = null
                if (eqOn) ensureEq()
            }
        })

        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(color = Color.Black, contentColor = Color.White) { PlayerScreen() }
            }
        }
    }

    // ---------------------------------------------------------------- UI

    @Composable
    private fun PlayerScreen() {
        val am = remember { getSystemService(Context.AUDIO_SERVICE) as AudioManager }
        val maxVol = remember { am.getStreamMaxVolume(AudioManager.STREAM_MUSIC) }
        var volF by remember { mutableFloatStateOf(am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()) }

        var hud by remember { mutableStateOf<String?>(null) }
        var locked by remember { mutableStateOf(false) }
        var showUnlock by remember { mutableStateOf(false) }
        var controls by remember { mutableStateOf(true) }
        var interaction by remember { mutableIntStateOf(0) }
        var dialog by remember { mutableStateOf<String?>(null) }
        var speed by remember { mutableFloatStateOf(1f) }
        var muted by remember { mutableStateOf(false) }
        var night by remember { mutableStateOf(false) }
        var sleepMin by remember { mutableIntStateOf(0) }
        var abA by remember { mutableLongStateOf(-1L) }
        var abB by remember { mutableLongStateOf(-1L) }
        var resizeIdx by remember { mutableIntStateOf(0) }
        var pos by remember { mutableLongStateOf(0L) }
        var dur by remember { mutableLongStateOf(0L) }
        var dragging by remember { mutableStateOf(false) }
        var dragVal by remember { mutableFloatStateOf(0f) }

        val resizeModes = listOf(
            AspectRatioFrameLayout.RESIZE_MODE_FIT,
            AspectRatioFrameLayout.RESIZE_MODE_FILL,
            AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
            AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH,
            AspectRatioFrameLayout.RESIZE_MODE_FIXED_HEIGHT
        )
        val resizeNames = listOf("Fit", "Fill", "Zoom", "Width", "Height")
        val speedOptions = listOf(0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f, 3f)
        val sleepOptions = listOf(0, 10, 15, 30, 45, 60, 90)

        LaunchedEffect(hud) { if (hud != null) { delay(800); hud = null } }
        LaunchedEffect(showUnlock) { if (showUnlock) { delay(3000); showUnlock = false } }
        LaunchedEffect(controls, interaction, isPlayingState) {
            if (controls && isPlayingState) { delay(4000); controls = false }
        }
        LaunchedEffect(Unit) {
            while (true) {
                if (!dragging) {
                    pos = player.currentPosition
                    dur = player.duration.coerceAtLeast(0)
                }
                delay(250)
            }
        }
        LaunchedEffect(sleepMin) {
            if (sleepMin > 0) {
                delay(sleepMin * 60_000L)
                player.pause()
                sleepMin = 0
                toast("Sleep timer: paused")
            }
        }
        LaunchedEffect(abA, abB) {
            if (abA >= 0 && abB > abA) {
                while (true) {
                    delay(100)
                    if (player.currentPosition >= abB) player.seekTo(abA)
                }
            }
        }

        fun poke() { interaction++ }

        fun seekBy(ms: Long) {
            val target = (player.currentPosition + ms).coerceIn(0, player.duration.coerceAtLeast(0))
            player.seekTo(target)
            val s = ms / 1000
            hud = if (s >= 0) "+${s}s" else "${s}s"
        }

        fun adjust(left: Boolean, delta: Float) {
            if (left) {
                val cur = window.attributes.screenBrightness.let { if (it < 0) 0.5f else it }
                val n = (cur + delta).coerceIn(0.02f, 1f)
                window.attributes = window.attributes.apply { screenBrightness = n }
                hud = "Brightness ${(n * 100).roundToInt()}%"
            } else {
                volF = (volF + delta * maxVol).coerceIn(0f, maxVol.toFloat())
                am.setStreamVolume(AudioManager.STREAM_MUSIC, volF.roundToInt(), 0)
                hud = "Volume ${(volF / maxVol * 100).roundToInt()}%"
            }
        }

        Box(Modifier.fillMaxSize().background(Color.Black)) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        this.player = this@PlayerActivity.player
                        useController = false
                    }
                },
                update = { it.resizeMode = resizeModes[resizeIdx] }
            )

            if (night) Box(Modifier.fillMaxSize().background(Color(0x80000000)))

            // Gestures
            Box(
                Modifier.fillMaxSize()
                    .pointerInput(locked) {
                        detectTapGestures(
                            onTap = {
                                if (locked) showUnlock = true else controls = !controls
                            },
                            onDoubleTap = { o ->
                                if (!locked) seekBy(if (o.x > size.width / 2) 10_000 else -10_000)
                            }
                        )
                    }
                    .pointerInput(locked) {
                        if (!locked) detectVerticalDragGestures { change, dy ->
                            val left = change.position.x < size.width / 2
                            adjust(left, -dy / size.height)
                        }
                    }
                    .pointerInput(locked) {
                        if (!locked) {
                            var acc = 0f
                            detectHorizontalDragGestures(
                                onDragStart = { acc = 0f },
                                onDragEnd = { if (acc != 0f) seekBy((acc / size.width * 90_000).toLong()) },
                                onDragCancel = { acc = 0f },
                                onHorizontalDrag = { _, dx -> acc += dx }
                            )
                        }
                    }
            )

            if (!inPip) {
                if (locked) {
                    if (showUnlock) {
                        Box(
                            Modifier.align(Alignment.CenterStart).padding(16.dp)
                                .background(Color(0x99000000), RoundedCornerShape(8.dp))
                        ) { Chip("Unlock") { locked = false; controls = true } }
                    }
                } else if (controls) {
                    Column(Modifier.fillMaxSize().displayCutoutPadding()) {
                        Row(
                            Modifier.fillMaxWidth().background(Color(0x99000000)).padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = { finish() }) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White)
                            }
                            Text(
                                curTitle, Modifier.weight(1f), color = Color.White,
                                maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                        }
                        Row(
                            Modifier.fillMaxWidth().background(Color(0x66000000))
                                .horizontalScroll(rememberScrollState()).padding(vertical = 4.dp)
                        ) {
                            Chip("Night", night) { night = !night; poke() }
                            Chip("Shuffle", shuffleState) {
                                player.shuffleModeEnabled = !player.shuffleModeEnabled; poke()
                            }
                            Chip(
                                when (repeatState) {
                                    Player.REPEAT_MODE_ONE -> "Loop: One"
                                    Player.REPEAT_MODE_ALL -> "Loop: All"
                                    else -> "Loop"
                                },
                                repeatState != Player.REPEAT_MODE_OFF
                            ) {
                                player.repeatMode = when (player.repeatMode) {
                                    Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ONE
                                    Player.REPEAT_MODE_ONE -> Player.REPEAT_MODE_ALL
                                    else -> Player.REPEAT_MODE_OFF
                                }
                                poke()
                            }
                            Chip(if (muted) "Muted" else "Mute", muted) {
                                muted = !muted
                                player.volume = if (muted) 0f else 1f
                                poke()
                            }
                            Chip(if (sleepMin > 0) "Sleep ${sleepMin}m" else "Sleep", sleepMin > 0) {
                                dialog = "sleep"; poke()
                            }
                            Chip(
                                when {
                                    abA < 0 -> "A-B"
                                    abB < 0 -> "A set"
                                    else -> "A-B on"
                                },
                                abA >= 0
                            ) {
                                if (abA < 0) {
                                    abA = player.currentPosition
                                    hud = "A set"
                                } else if (abB < 0) {
                                    val b = player.currentPosition
                                    if (b > abA) {
                                        abB = b
                                        player.seekTo(abA)
                                        hud = "A-B repeat on"
                                    } else {
                                        abA = -1L
                                    }
                                } else {
                                    abA = -1L; abB = -1L
                                    hud = "A-B off"
                                }
                                poke()
                            }
                            Chip("${speed}x", speed != 1f) { dialog = "speed"; poke() }
                            Chip("Screenshot") { takeScreenshot(); poke() }
                            Chip("Audio") { dialog = "audio"; poke() }
                            Chip("Subtitles") { dialog = "subs"; poke() }
                            Chip("Equalizer", eqOn) {
                                if (ensureEq() != null) dialog = "eq" else toast("Equalizer not available")
                                poke()
                            }
                            Chip("Rotate") { toggleRotation(); poke() }
                        }

                        Spacer(Modifier.weight(1f))

                        Column(Modifier.fillMaxWidth().background(Color(0x99000000)).padding(8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(fmt(if (dragging) dragVal.toLong() else pos), color = Color.White)
                                Slider(
                                    value = if (dragging) dragVal else pos.toFloat(),
                                    onValueChange = { dragging = true; dragVal = it; poke() },
                                    onValueChangeFinished = {
                                        player.seekTo(dragVal.toLong())
                                        pos = dragVal.toLong()
                                        dragging = false
                                    },
                                    valueRange = 0f..maxOf(dur, 1L).toFloat(),
                                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                                )
                                Text(fmt(dur), color = Color.White)
                            }
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Chip("Lock") { locked = true; showUnlock = true }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    CtrlIcon("prev") {
                                        if (player.hasPreviousMediaItem()) player.seekToPreviousMediaItem()
                                        else hud = "No previous video"
                                        poke()
                                    }
                                    CtrlIcon(if (isPlayingState) "pause" else "play") {
                                        if (player.isPlaying) player.pause() else {
                                            if (player.playbackState == Player.STATE_ENDED) player.seekTo(0)
                                            player.play()
                                        }
                                        poke()
                                    }
                                    CtrlIcon("next") {
                                        if (player.hasNextMediaItem()) player.seekToNextMediaItem()
                                        else hud = "No next video"
                                        poke()
                                    }
                                }
                                Chip(resizeNames[resizeIdx]) {
                                    resizeIdx = (resizeIdx + 1) % resizeModes.size
                                    hud = resizeNames[resizeIdx]
                                    poke()
                                }
                                Chip("PiP") { enterPip() }
                            }
                        }
                    }
                }
            }

            hud?.let {
                Text(
                    it,
                    color = Color.White,
                    modifier = Modifier.align(Alignment.Center)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xAA000000))
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }

            when (dialog) {
                "speed" -> ChoiceDialog(
                    "Playback speed", speedOptions.map { "${it}x" },
                    { i ->
                        speed = speedOptions[i]
                        player.setPlaybackSpeed(speed)
                        dialog = null
                    },
                    { dialog = null }
                )
                "sleep" -> ChoiceDialog(
                    "Sleep timer", sleepOptions.map { if (it == 0) "Off" else "$it min" },
                    { i -> sleepMin = sleepOptions[i]; dialog = null },
                    { dialog = null }
                )
                "audio" -> {
                    val groups = tracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO }
                    if (groups.isEmpty()) {
                        LaunchedEffect(Unit) { toast("No audio tracks"); dialog = null }
                    } else {
                        ChoiceDialog(
                            "Audio track",
                            groups.mapIndexed { i, g ->
                                val f = g.getTrackFormat(0)
                                "${i + 1}. ${f.label ?: f.language ?: "Audio"}" +
                                    (if (f.channelCount > 0) " (${f.channelCount}ch)" else "")
                            },
                            { i ->
                                player.trackSelectionParameters = player.trackSelectionParameters
                                    .buildUpon()
                                    .setOverrideForType(TrackSelectionOverride(groups[i].mediaTrackGroup, 0))
                                    .build()
                                dialog = null
                            },
                            { dialog = null }
                        )
                    }
                }
                "subs" -> {
                    val groups = tracks.groups.filter { it.type == C.TRACK_TYPE_TEXT }
                    val options = listOf("Off") +
                        groups.mapIndexed { i, g ->
                            val f = g.getTrackFormat(0)
                            "${i + 1}. ${f.label ?: f.language ?: "Subtitle"}"
                        } + "Load from file…"
                    ChoiceDialog(
                        "Subtitles", options,
                        { i ->
                            when {
                                i == 0 -> player.trackSelectionParameters = player.trackSelectionParameters
                                    .buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build()
                                i == options.lastIndex -> subtitlePicker.launch(arrayOf("*/*"))
                                else -> player.trackSelectionParameters = player.trackSelectionParameters
                                    .buildUpon()
                                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                                    .setOverrideForType(TrackSelectionOverride(groups[i - 1].mediaTrackGroup, 0))
                                    .build()
                            }
                            dialog = null
                        },
                        { dialog = null }
                    )
                }
                "eq" -> EqDialog { dialog = null }
            }
        }
    }

    @Composable
    private fun ChoiceDialog(
        title: String,
        options: List<String>,
        onPick: (Int) -> Unit,
        onDismiss: () -> Unit
    ) {
        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text(title) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    options.forEachIndexed { i, o ->
                        TextButton(onClick = { onPick(i) }, modifier = Modifier.fillMaxWidth()) {
                            Text(o, modifier = Modifier.fillMaxWidth())
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
        )
    }

    @Composable
    private fun EqDialog(onDismiss: () -> Unit) {
        val e = eq ?: return
        var on by remember { mutableStateOf(eqOn) }
        val range = e.bandLevelRange
        val min = range[0].toFloat()
        val max = range[1].toFloat()
        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("Equalizer") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Enable", Modifier.weight(1f))
                        Switch(checked = on, onCheckedChange = {
                            on = it; eqOn = it; e.enabled = it
                        })
                    }
                    for (b in 0 until e.numberOfBands) {
                        val band = b.toShort()
                        var lvl by remember { mutableFloatStateOf(e.getBandLevel(band).toFloat()) }
                        val hz = e.getCenterFreq(band) / 1000
                        Text(if (hz >= 1000) "%.1f kHz".format(hz / 1000.0) else "$hz Hz")
                        Slider(
                            value = lvl,
                            onValueChange = {
                                lvl = it
                                val s = it.roundToInt().toShort()
                                e.setBandLevel(band, s)
                                eqLevels[b] = s
                            },
                            valueRange = min..max
                        )
                    }
                }
            },
            confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
        )
    }

    @Composable
    private fun Chip(label: String, active: Boolean = false, onClick: () -> Unit) {
        Text(
            label,
            color = if (active) MaterialTheme.colorScheme.primary else Color.White,
            fontSize = 14.sp,
            modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .clickable(onClick = onClick)
                .padding(horizontal = 12.dp, vertical = 10.dp)
        )
    }

    @Composable
    private fun CtrlIcon(kind: String, onClick: () -> Unit) {
        Box(
            Modifier.size(56.dp).clip(CircleShape).clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            Canvas(Modifier.size(28.dp)) {
                val w = size.width
                val h = size.height
                when (kind) {
                    "play" -> drawPath(Path().apply {
                        moveTo(w * 0.2f, h * 0.08f); lineTo(w * 0.2f, h * 0.92f)
                        lineTo(w * 0.92f, h * 0.5f); close()
                    }, Color.White)
                    "pause" -> {
                        drawRect(Color.White, Offset(w * 0.18f, h * 0.1f), Size(w * 0.22f, h * 0.8f))
                        drawRect(Color.White, Offset(w * 0.6f, h * 0.1f), Size(w * 0.22f, h * 0.8f))
                    }
                    "prev" -> {
                        drawRect(Color.White, Offset(w * 0.1f, h * 0.15f), Size(w * 0.12f, h * 0.7f))
                        drawPath(Path().apply {
                            moveTo(w * 0.9f, h * 0.12f); lineTo(w * 0.9f, h * 0.88f)
                            lineTo(w * 0.3f, h * 0.5f); close()
                        }, Color.White)
                    }
                    "next" -> {
                        drawRect(Color.White, Offset(w * 0.78f, h * 0.15f), Size(w * 0.12f, h * 0.7f))
                        drawPath(Path().apply {
                            moveTo(w * 0.1f, h * 0.12f); lineTo(w * 0.1f, h * 0.88f)
                            lineTo(w * 0.7f, h * 0.5f); close()
                        }, Color.White)
                    }
                }
            }
        }
    }

    // ---------------------------------------------------------------- helpers

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%02d:%02d".format(m, sec)
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun toggleRotation() {
        requestedOrientation =
            if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE)
                ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
    }

    private fun ensureEq(): Equalizer? {
        if (eq == null) {
            val id = player.audioSessionId
            if (id == C.AUDIO_SESSION_ID_UNSET) return null
            try {
                eq = Equalizer(0, id).also { e ->
                    e.enabled = eqOn
                    eqLevels.forEach { (b, l) -> e.setBandLevel(b.toShort(), l) }
                }
            } catch (_: Exception) {
                eq = null
            }
        }
        return eq
    }

    private fun displayName(uri: Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c -> if (c.moveToFirst()) return c.getString(0) ?: "" }
        } catch (_: Exception) {}
        return uri.lastPathSegment ?: ""
    }

    private fun loadSubtitle(uri: Uri) {
        val name = displayName(uri).lowercase()
        val mime = when {
            name.endsWith(".vtt") -> MimeTypes.TEXT_VTT
            name.endsWith(".ass") || name.endsWith(".ssa") -> MimeTypes.TEXT_SSA
            else -> MimeTypes.APPLICATION_SUBRIP
        }
        val cur = player.currentMediaItem ?: return
        val idx = player.currentMediaItemIndex
        val pos = player.currentPosition
        val sub = MediaItem.SubtitleConfiguration.Builder(uri)
            .setMimeType(mime)
            .setLanguage("und")
            .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
            .build()
        player.replaceMediaItem(idx, cur.buildUpon().setSubtitleConfigurations(listOf(sub)).build())
        player.seekTo(idx, pos)
        player.trackSelectionParameters = player.trackSelectionParameters
            .buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false).build()
        toast("Subtitle loaded")
    }

    private fun takeScreenshot() {
        val src = player.currentMediaItem?.localConfiguration?.uri ?: return
        val posUs = player.currentPosition * 1000
        thread {
            try {
                val r = MediaMetadataRetriever()
                if (src.scheme == "http" || src.scheme == "https") {
                    r.setDataSource(src.toString(), HashMap())
                } else {
                    r.setDataSource(this, src)
                }
                val bmp = r.getFrameAtTime(posUs, MediaMetadataRetriever.OPTION_CLOSEST)
                r.release()
                if (bmp == null) {
                    runOnUiThread { toast("Screenshot failed") }
                    return@thread
                }
                val name = "Kenexo_${System.currentTimeMillis()}.jpg"
                if (Build.VERSION.SDK_INT >= 29) {
                    val values = ContentValues().apply {
                        put(MediaStore.Images.Media.DISPLAY_NAME, name)
                        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/KenexoPlayer")
                    }
                    val out = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    if (out == null) {
                        runOnUiThread { toast("Screenshot failed") }
                        return@thread
                    }
                    contentResolver.openOutputStream(out)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
                    runOnUiThread { toast("Saved to Pictures/KenexoPlayer") }
                } else {
                    val dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES) ?: filesDir
                    File(dir, name).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
                    runOnUiThread { toast("Saved in app folder") }
                }
            } catch (e: Exception) {
                runOnUiThread { toast("Screenshot failed") }
            }
        }
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT >= 26) {
            enterPictureInPictureMode(
                PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build()
            )
        }
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onUserLeaveHint() {
        if (::player.isInitialized && player.isPlaying) enterPip()
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPip = isInPictureInPictureMode
    }

    private fun savePosition() {
        if (!::player.isInitialized) return
        val key = player.currentMediaItem?.localConfiguration?.uri?.toString() ?: return
        val pos = if (player.playbackState == Player.STATE_ENDED) 0L else player.currentPosition
        prefs.edit().putLong(key, pos).apply()
    }

    override fun onPause() {
        super.onPause()
        savePosition()
        if (!inPip) player.pause()
    }

    override fun onStop() {
        super.onStop()
        savePosition()
        if (inPip) player.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::player.isInitialized) {
            savePosition()
            eq?.release()
            player.release()
        }
    }
}
