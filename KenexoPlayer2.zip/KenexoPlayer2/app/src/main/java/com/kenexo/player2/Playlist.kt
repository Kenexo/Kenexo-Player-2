package com.kenexo.player2

/** Holds the list the user was browsing so the player can do next/previous/shuffle. */
object Playlist {
    var items: List<VideoItem> = emptyList()
}
